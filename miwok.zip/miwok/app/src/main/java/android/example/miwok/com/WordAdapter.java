package android.example.miwok.com;

import android.content.Context;
import android.media.MediaPlayer;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.example.miwok.com.Word;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import java.util.List;

public class WordAdapter extends ArrayAdapter {
    private int  mColourResourceId;

    private MediaPlayer mMediaPlayer;
    public WordAdapter(Context context, ArrayList<Word> pWords, int colorResourceId) {
        super(context, 0, pWords);
        mColourResourceId=colorResourceId;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        // Check if the existing view is being reused, otherwise inflate the view
        View listItemView = convertView;

        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.list_item, parent, false);
        }
        Word my_word = (Word) getItem(position);
        TextView miwokTextView = (TextView) listItemView.findViewById(R.id.miwok_text_view);
        miwokTextView.setText(my_word.getMiwokTranslationId());
       //Set the theme color for the list view
       View textContainer= listItemView.findViewById(R.id.background_layout);
       //Find the color that the resource id map to
       int color = ContextCompat.getColor(getContext(),mColourResourceId);
       //set the background color of the text container view
       textContainer.setBackgroundColor(color);

        TextView defaultTextView = (TextView) listItemView.findViewById(R.id.default_text_view);
        defaultTextView.setText(my_word.getDefaultTranslationId());

        // Find the ImageView in the list_item.xml layout with the ID list_item_icon
        ImageView iconView = (ImageView) listItemView.findViewById(R.id.image);
        // Get the image resource ID from the current word object and
        // set the image to iconView
        if (my_word.hasImage()) {
            // Set the ImageView to the image resource specified in the current word
        iconView.setImageResource(my_word.getImageResourceId());
        //Make sure the view is visible
            iconView.setVisibility(View.VISIBLE);
        } else { //Otherwise hide the ImageView (set visibility to GONE)
            iconView.setVisibility(View.GONE);
        }
        return listItemView;


}
}
